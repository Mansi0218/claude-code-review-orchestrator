# Testing Standards

## Test Organization

- Organize tests by system: test_<system_name>.py
- Use pytest markers for categorization (@pytest.mark.<system>)
- Group related tests in classes

## Test Coverage

- Aim for 100% coverage of public APIs
- Test edge cases and error conditions
- Test Model, Harness, and Orchestration layers separately

## Fixtures

- Use pytest fixtures for common test setup
- Prefer fixture scope of 'function' for isolation
- Clean up resources in fixtures (use yield pattern)

## Assertions

- Use descriptive assertions
- Test one concept per test function
- Verify both positive and negative cases

## Test Data

- Use minimal realistic test data
- Avoid hardcoding paths (use tmp_path fixture)
- Clean up test artifacts after execution
