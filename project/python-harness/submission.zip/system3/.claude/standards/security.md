# Security Standards

## Input Validation

- Validate all external inputs
- Sanitize file paths to prevent directory traversal
- Use Pydantic validators for data validation

## SQL Injection Prevention

- Use parameterized queries (? placeholders)
- Never concatenate user input into SQL
- Use SQLAlchemy or similar ORM when possible

## File System Security

- Validate file paths before operations
- Restrict file operations to designated directories
- Check file permissions before reading/writing

## Sensitive Data

- Never log sensitive information
- Use environment variables for secrets
- Sanitize error messages to prevent information disclosure

## Dependencies

- Keep dependencies updated
- Review dependency licenses
- Use virtual environments for isolation
