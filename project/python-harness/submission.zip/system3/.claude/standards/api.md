# API Conventions and Standards

## Naming Conventions

- Use snake_case for functions and variables
- Use PascalCase for classes
- Use UPPER_CASE for constants

## Error Handling

- Raise specific exceptions (ValueError, FileNotFoundError, etc.)
- Provide descriptive error messages
- Document expected exceptions in docstrings

## Return Values

- Use type hints for all function signatures
- Return explicit types (avoid Any when possible)
- Use Pydantic models for complex return types

## Documentation

- All public functions must have docstrings
- Include Args, Returns, and Raises sections
- Document side effects and state modifications
